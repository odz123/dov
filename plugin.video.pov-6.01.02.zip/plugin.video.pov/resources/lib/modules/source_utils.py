import re
import json
import unicodedata
from string import printable
from urllib.parse import unquote, unquote_plus
from fenom.control import setting as fenom_getSetting, setSetting as fenom_setSetting
from indexers.metadata import season_episodes_meta
from modules import kodi_utils
from modules.settings import check_prescrape_sources, date_offset, metadata_user_info
from modules.utils import manual_function_import, adjust_premiered_date, get_datetime, jsondate_to_datetime, subtract_dates

string = str
# Frozensets for O(1) membership testing in hot-path quality detection functions
RES_4K = frozenset(('.4k', 'hd4k', '4khd', '.uhd', 'ultrahd', 'ultra.hd', 'hd2160', '2160hd', '2160', '2160p', '216o', '216op'))
RES_1080 = frozenset(('1080', '1080p', '1080i', 'hd1080', '1080hd', 'hd1080p', 'm1080p', 'fullhd', 'full.hd', '1o8o', '1o8op', '108o', '108op', '1o80', '1o80p'))
RES_720 = frozenset(('720', '720p', '720i', 'hd720', '720hd', 'hd720p', '72o', '72op'))
CAM = frozenset(('.cam.', 'camrip', 'hdcam', '.hd.cam', 'cam.rip', 'dvdcam'))
SCR = frozenset(('.scr.', 'screener', 'dvdscr', 'dvd.scr', '.r5', '.r6'))
TELE = frozenset(('.tc.', 'tsrip', 'hdts', 'hdtc', '.hd.tc', 'dvdts', 'telesync', '.ts.'))
VIDEO_3D = frozenset(('.3d.', '.sbs.', '.hsbs', 'sidebyside', 'side.by.side', 'stereoscopic', '.tab.', '.htab.', 'topandbottom', 'top.and.bottom'))
DOLBY_VISION = frozenset(('dolby.vision', 'dolbyvision', '.dovi.', '.dv.'))
HDR = frozenset(('2160p.uhd.bluray', '2160p.uhd.blu.ray', '2160p.bluray.hevc.truehd', '2160p.blu.ray.hevc.truehd', '2160p.bluray.hevc.dts.hd.ma', '2160p.blu.ray.hevc.dts.hd.ma',
		'.hdr.', 'hdr10', 'hdr.10', 'uhd.bluray.2160p', 'uhd.blu.ray.2160p'))
HDR_TRUE = frozenset(('.hdr.', 'hdr10', 'hdr.10'))
CODEC_H264 = frozenset(('avc', 'h264', 'h.264', 'x264', 'x.264'))
CODEC_H265 = frozenset(('h265', 'h.265', 'hevc', 'x265', 'x.265'))
CODEC_XVID = frozenset(('xvid', '.x.vid'))
CODEC_DIVX = frozenset(('divx', 'div2', 'div3', 'div4'))
CODEC_MPEG = frozenset(('.mpg', '.mp2', '.mpeg', '.mpe', '.mpv', '.mp4', '.m4p', '.m4v', 'msmpeg', 'mpegurl'))
CODEC_MKV = frozenset(('.mkv', 'matroska'))
REMUX = frozenset(('remux', 'bdremux'))
BLURAY = frozenset(('bluray', 'blu.ray', 'bdrip', 'bd.rip'))
DVD = frozenset(('dvdrip', 'dvd.rip'))
WEB = frozenset(('.web.', 'webdl', 'web.dl', 'web-dl', 'webrip', 'web.rip'))
HDRIP = frozenset(('.hdrip', '.hd.rip'))
DOLBY_TRUEHD = frozenset(('true.hd', 'truehd'))
DOLBY_DIGITALPLUS = frozenset(('dolby.digital.plus', 'dolbydigital.plus', 'dolbydigitalplus', 'dd.plus.', 'ddplus', '.ddp.', 'ddp2', 'ddp5', 'ddp7', 'eac3', '.e.ac3'))
DOLBY_DIGITALEX = frozenset(('.dd.ex.', 'ddex', 'dolby.ex.', 'dolby.digital.ex.', 'dolbydigital.ex.'))
DOLBYDIGITAL = frozenset(('dd2.', 'dd5', 'dd7', 'dolby.digital', 'dolbydigital', '.ac3', '.ac.3.', '.dd.'))
DTSX = frozenset(('dts.x.', 'dtsx'))
DTS_HDMA = frozenset(('hd.ma', 'hdma'))
DTS_HD = frozenset(('dts.hd.', 'dtshd'))
AUDIO_8CH = frozenset(('ch8.', '8ch.', '7.1ch', '7.1.'))
AUDIO_7CH = frozenset(('ch7.', '7ch.', '6.1ch', '6.1.'))
AUDIO_6CH = frozenset(('ch6.', '6ch.', '5.1ch', '5.1.'))
AUDIO_2CH = frozenset(('ch2', '2ch', '2.0ch', '2.0.', 'audio.2.0.', 'stereo'))
MULTI_LANG = frozenset(('hindi.eng', 'ara.eng', 'ces.eng', 'chi.eng', 'cze.eng', 'dan.eng', 'dut.eng', 'ell.eng', 'esl.eng', 'esp.eng', 'fin.eng', 'fra.eng', 'fre.eng',
			'frn.eng', 'gai.eng', 'ger.eng', 'gle.eng', 'gre.eng', 'gtm.eng', 'heb.eng', 'hin.eng', 'hun.eng', 'ind.eng', 'iri.eng', 'ita.eng', 'jap.eng', 'jpn.eng',
			'kor.eng', 'lat.eng', 'lebb.eng', 'lit.eng', 'nor.eng', 'pol.eng', 'por.eng', 'rus.eng', 'som.eng', 'spa.eng', 'sve.eng', 'swe.eng', 'tha.eng', 'tur.eng',
			'uae.eng', 'ukr.eng', 'vie.eng', 'zho.eng', 'dual.audio', 'multi'))
SUBS = frozenset(('subita', 'subfrench', 'subspanish', 'subtitula', 'swesub', 'nl.subs'))
ADS = frozenset(('1xbet', 'betwin'))

# Pre-compiled regex patterns for hot-path functions
_RE_NON_ALNUM_DASH = re.compile(r'[^A-Za-z0-9-]+')
_RE_NON_ALNUM_DASH_TILDE = re.compile(r'[^a-z0-9-~]+')
_RE_NON_ALNUM = re.compile(r'[^a-z0-9]+')
_RE_BRACKET_PREFIX = re.compile(r'^\[.*?]', re.I)
_RE_HTML_ENTITY = re.compile(r'&#(\d+);')
_RE_HTML_ENTITY_FIX = re.compile(r'(&#[0-9]+)([^;^0-9]+)')
_RE_CLEAN_TITLE = re.compile(r'\n|([\[({].+?[})\]])|([:;–\-"\',!_.?~$@])|\s')
_RE_FIND_SEASON = [re.compile(p) for p in (r's(\d+)', r's\.(\d+)', r'(\d+)x', r'(\d+)\.x', r'season(\d+)', r'season\.(\d+)')]
UNWANTED_TAGS = ('tamilrockers.com', 'www.tamilrockers.com', 'www.tamilrockers.ws', 'www.tamilrockers.pl', 'www-tamilrockers-cl', 'www.tamilrockers.cl', 'www.tamilrockers.li',
				'www.tamilrockerrs.pl', 'www.tamilmv.bid', 'www.tamilmv.biz', 'www.1tamilmv.org', 'gktorrent-bz', 'gktorrent-com', 'www.torrenting.com', 'www.torrenting.org',
				'www-torrenting-com', 'www-torrenting-org', 'katmoviehd.pw', 'katmoviehd-pw', 'www.torrent9.nz', 'www-torrent9-uno', 'torrent9-cz', 'torrent9.cz',
				'agusiq-torrents-pl', 'oxtorrent-bz', 'oxtorrent-com', 'oxtorrent.com', 'oxtorrent-sh', 'oxtorrent-vc', 'www.movcr.tv', 'movcr-com', 'www.movcr.to', '(imax)',
				'imax', 'xtorrenty.org', 'nastoletni.wilkoak', 'www.scenetime.com', 'kst-vn', 'www.movierulz.vc', 'www-movierulz-ht', 'www.2movierulz.ac', 'www.2movierulz.ms',
				'www.3movierulz.com', 'www.3movierulz.tv', 'www.3movierulz.ws', 'www.3movierulz.ms', 'www.7movierulz.pw', 'www.8movierulz.ws', 'mkvcinemas.live', 'www.bludv.tv',
				'ramin.djawadi', 'extramovies.casa', 'extramovies.wiki', '13+', '18+', 'taht.oyunlar', 'crazy4tv.com', 'karibu', '989pa.com', 'best-torrents-net', '1-3-3-8.com',
				'ssrmovies.club', 'va:', 'zgxybbs-fdns-uk', 'www.tamilblasters.mx', 'www.1tamilmv.work', 'www.xbay.me', 'crazy4tv-com', '(es)')

# Pre-compiled regex patterns for UNWANTED_TAGS to avoid re-compilation in check_title()
_UNWANTED_TAG_PATTERNS = {}
for _tag in UNWANTED_TAGS:
	if _tag.startswith('[') or _tag.startswith('+'):
		_UNWANTED_TAG_PATTERNS[_tag] = re.compile(r'^\\%s' % _tag, re.I)
	else:
		_UNWANTED_TAG_PATTERNS[_tag] = re.compile(r'^%s' % re.escape(_tag), re.I)

# Module-level cache for external sources to avoid repeated directory scans and imports
_external_sources_cache = {}
_external_sources_cache_all = {}

def external_sources(ret_all=False):
	"""Get external sources with caching to avoid repeated directory scans."""
	global _external_sources_cache, _external_sources_cache_all
	# Check if we have a cached result
	cache = _external_sources_cache_all if ret_all else _external_sources_cache
	if cache:
		return list(cache.values())
	source_list = []
	append = source_list.append
	enabled_set = set()
	for k, v in kodi_utils.make_settings_dict().items():
		if k.startswith('provider.') and v == 'true':
			parts = k.split('.')
			if len(parts) > 1:
				enabled_set.add(parts[1])
	dir_result = kodi_utils.list_dirs('special://home/addons/plugin.video.pov/resources/lib/magneto')
	files = dir_result[1] if len(dir_result) > 1 else []
	for item in files:
		try:
			module_name = item.split('.')[0]
			if module_name in ('__init__',): continue
			if not ret_all and module_name not in enabled_set: continue
			module = manual_function_import('magneto.%s' % module_name, 'source')
			append((module_name, module))
			# Cache the module for future use
			if ret_all:
				_external_sources_cache_all[module_name] = (module_name, module)
			else:
				_external_sources_cache[module_name] = (module_name, module)
		except Exception: pass
	return source_list

def clear_external_sources_cache():
	"""Clear the external sources cache. Call when provider settings change."""
	global _external_sources_cache, _external_sources_cache_all
	_external_sources_cache.clear()
	_external_sources_cache_all.clear()

def clear_stremio_addons_cache():
	"""Clear the stremio addons cache. Call when stremio settings change."""
	_stremio_addons_cache['str'] = None
	_stremio_addons_cache['addons'] = None

def _parse_stremio_addons(addons_str):
	"""Parse Stremio addons string, trying JSON first then ast.literal_eval for backward compatibility"""
	try:
		addons = json.loads(addons_str)
		return addons if isinstance(addons, list) else []
	except (json.JSONDecodeError, ValueError):
		pass
	try:
		import ast
		addons = ast.literal_eval(addons_str)
		return addons if isinstance(addons, list) else []
	except Exception:
		pass
	return []

# Cached stremio addon parsing to avoid re-parsing on every call
_stremio_addons_cache = {'str': None, 'addons': None}

def _get_stremio_addons():
	"""Get parsed stremio addons with caching to avoid repeated parsing."""
	addons_str = kodi_utils.get_setting('stremio.addons', '')
	if not addons_str:
		return []
	if _stremio_addons_cache['str'] == addons_str:
		return _stremio_addons_cache['addons']
	addons = _parse_stremio_addons(addons_str)
	_stremio_addons_cache['str'] = addons_str
	_stremio_addons_cache['addons'] = addons
	return addons

def stremio_is_configured():
	"""Check if Stremio is enabled with at least one addon configured.
	Returns True if Stremio can potentially provide streams."""
	try:
		if kodi_utils.get_setting('provider.stremio') != 'true':
			return False
		return bool(_get_stremio_addons())
	except Exception:
		return False


def stremio_has_debrid_addons():
	"""Check if the Stremio scraper has any addons configured with debrid credentials.
	Returns True if Stremio is enabled and has debrid-configured addons.
	Note: This only detects debrid patterns in URLs - some addons may have server-side
	debrid configuration that cannot be detected. Use stremio_is_configured() for a
	simpler check."""
	try:
		if kodi_utils.get_setting('provider.stremio') != 'true':
			return False
		addons = _get_stremio_addons()
		if not addons:
			return False
		debrid_patterns = (
			'realdebrid=', 'rd=', 'debridkey=',
			'premiumize=', 'pm=',
			'alldebrid=', 'ad=',
			'torbox=', 'tb=',
			'offcloud=', 'oc=',
			'debrid-link=', 'dl=',
			'easydebrid=', 'ed='
		)
		for addon in addons:
			if isinstance(addon, dict):
				config_url = addon.get('config_url', '')
				addon_url = addon.get('url', '')
				check_url = config_url or addon_url
			else:
				check_url = addon if isinstance(addon, str) else ''
			if check_url and any(pattern in check_url.lower() for pattern in debrid_patterns):
				return True
		return False
	except Exception:
		return False

# Module-level cache for internal source modules
_internal_sources_modules = {}

def internal_sources(active_sources, media_type, prescrape=False):
	"""Get internal sources with module caching to avoid repeated imports."""
	global _internal_sources_modules
	def import_info():
		# Cache directory listing to avoid repeated filesystem access
		if not _internal_sources_modules:
			dir_result = kodi_utils.list_dirs('special://home/addons/plugin.video.pov/resources/lib/scrapers')
			files = dir_result[1] if len(dir_result) > 1 else []
			for item in files:
				try:
					module_name = item.split('.')[0]
					if module_name in ('__init__', 'external', 'folders'): continue
					module = manual_function_import('scrapers.%s' % module_name, 'source')
					_internal_sources_modules[module_name] = module
				except Exception: pass
		# Build result from cached modules
		active_set = set(active_sources)  # O(1) lookup
		for module_name, module in _internal_sources_modules.items():
			if module_name not in active_set: continue
			if prescrape and not check_prescrape_sources(module_name, media_type): continue
			yield ('internal', module, module_name)
	try: sourceDict = list(import_info())
	except Exception: sourceDict = []
	return sourceDict

# Cache the folders module to avoid repeated imports
_folders_module_cache = None

def internal_folders_import(folders):
	global _folders_module_cache
	if _folders_module_cache is None:
		_folders_module_cache = manual_function_import('scrapers.folders', 'source')
	module = _folders_module_cache
	def import_info():
		for item in folders:
			yield ('folders', (module, (item[1], item[0])), item[0])
	try: sourceDict = list(import_info())
	except Exception: sourceDict = []
	return sourceDict

def get_aliases_titles(aliases):
	try: result = [i['title'] for i in aliases]
	except Exception: result = []
	return result

def internal_results(provider, sources):
	quality_count = sources_quality_count(sources)
	kodi_utils.set_property('%s.internal_results' % provider, json.dumps(quality_count))

_quality_bucket = {'4K': '4K', '1440p': '1080p', '1080p': '1080p', '720p': '720p', 'HD': '720p'}

def sources_quality_count(sources):
	counts = {'4K': 0, '1080p': 0, '720p': 0, 'SD': 0, 'total': 0}
	for i in sources:
		counts[_quality_bucket.get(i['quality'], 'SD')] += 1
		counts['total'] += 1
	return counts

def normalize(title):
	try:
		title = ''.join(c for c in unicodedata.normalize('NFKD', title) if unicodedata.category(c) != 'Mn')
		return string(title)
	except Exception: return title

def enable_disable(folder):
	try:
		icon = 'special://home/addons/plugin.video.pov/resources/lib/fenom/fenom_icon.png'
		enabled, disabled = scrapers_status(folder)
		all_sources = sorted(enabled + disabled)
		sources_idx = {item: idx for idx, item in enumerate(all_sources)}  # O(1) lookup
		preselect = [sources_idx[i] for i in enabled if i in sources_idx]
		list_items = [{'line1': i.upper(), 'icon': icon} for i in all_sources]
		kwargs = {'items': json.dumps(list_items), 'heading': 'POV', 'multi_choice': 'true', 'preselect': preselect}
		chosen = kodi_utils.select_dialog(all_sources, **kwargs)
		if chosen is None: return
		for i in all_sources:
			if i in chosen: fenom_setSetting('provider.' + i, 'true')
			else: fenom_setSetting('provider.' + i, 'false')
		return kodi_utils.notification(32576, 1500)
	except Exception: return kodi_utils.notification(32574, 1500)

def scrapers_status(folder='all'):
	providers = scraper_names(folder)
	enabled = [i for i in providers if fenom_getSetting('provider.' + i) == 'true']
	disabled = [i for i in providers if i not in enabled]
	return enabled, disabled

def scraper_names(folder):
	providerList = []
	append = providerList.append
	source_folder_location = 'special://home/addons/plugin.video.pov/resources/lib/magneto/%s'
	sourceSubFolders = {'hosters': '', 'torrents': ''}
	if folder == 'all': sourceSubFolders = ['']
	else: sourceSubFolders = [v for k, v in sourceSubFolders.items() if k == folder]
	for subfolder in sourceSubFolders:
		files = kodi_utils.list_dirs(source_folder_location % subfolder)[1]
		for filename in files:
			module_name = filename.split('.')[0]
			if module_name == '__init__': continue
			append(module_name)
	return providerList

def pack_enable_check(meta, season, episode):
	try:
		extra_info = meta['extra_info']
		status = extra_info['status']
		if status in ('Ended', 'Canceled'): return True, True
		adjust_hours = date_offset()
		current_date = get_datetime()
		meta_user_info = metadata_user_info()
		episodes_data = season_episodes_meta(season, meta, meta_user_info)
		unaired_episodes = [adjust_premiered_date(i['premiered'], adjust_hours)[0] for i in episodes_data]
		if None in unaired_episodes or any(i > current_date for i in unaired_episodes): return False, False
		else: return True, False
	except Exception: pass
	return False, False

def get_filename_match(title, url, name=None):
	from modules.utils import clean_file_name
	if name: return clean_file_name(name)
	from modules.utils import clean_title, normalize
	title_match = None
	try:
		title = clean_title(normalize(title))
		name_url = unquote(url)
		try: file_name = clean_title(name_url.split('/')[-1])
		except Exception: return title_match
		test = name_url.split('/')
		for item in test:
			test_url = string(clean_title(normalize(item)))
			if title in test_url:
				title_match = clean_file_name(string(item)).replace('html', ' ').replace('+', ' ')
				break
	except Exception: pass
	return title_match

def supported_video_extensions():
	extensions = kodi_utils.supported_media().split('|')
	return tuple(i for i in extensions if i not in ('', '.iso', '.zip'))

def seas_ep_query_list(season, episode):
	season = int(season)
	episode = int(episode)
	return ['s%de%02d' % (season, episode),
			's%02de%02d' % (season, episode),
			'%dx%02d' % (season, episode),
			'%02dx%02d' % (season, episode),
			'season%02depisode%02d' % (season, episode),
			'season%depisode%02d' % (season, episode),
			'season%depisode%d' % (season, episode)]

_seas_ep_pattern_cache = {}

def _get_seas_ep_pattern(season, episode):
	"""Get or compile and cache the regex pattern for a given season/episode pair."""
	key = (int(season), int(episode))
	if key in _seas_ep_pattern_cache:
		return _seas_ep_pattern_cache[key]
	str_season, str_episode = string(season), string(episode)
	season_fill, episode_fill = str_season.zfill(2), str_episode.zfill(2)
	str_ep_plus_1, str_ep_minus_1 = string(episode+1), string(episode-1)
	string1 = r'(s<<S>>[.-]?e[p]?[.-]?<<E>>[.-])'
	string2 = r'(season[.-]?<<S>>[.-]?episode[.-]?<<E>>[.-])|([s]?<<S>>[x.]<<E>>[.-])'
	string3 = r'(s<<S>>e<<E1>>[.-]?e?<<E2>>[.-])'
	string4 = r'([.-]<<S>>[.-]?<<E>>[.-])'
	string5 = r'(episode[.-]?<<E>>[.-])'
	string6 = r'([.-]e[p]?[.-]?<<E>>[.-])'
	string7 = r'(^(?=.*\.e?0*<<E>>\.)(?:(?!((?:s|season)[.-]?\d+[.-x]?(?:ep?|episode)[.-]?\d+)|\d+x\d+).)*$)'
	string_list = [
		string1.replace('<<S>>', season_fill).replace('<<E>>', episode_fill),
		string1.replace('<<S>>', str_season).replace('<<E>>', episode_fill),
		string1.replace('<<S>>', season_fill).replace('<<E>>', str_episode),
		string1.replace('<<S>>', str_season).replace('<<E>>', str_episode),
		string2.replace('<<S>>', season_fill).replace('<<E>>', episode_fill),
		string2.replace('<<S>>', str_season).replace('<<E>>', episode_fill),
		string2.replace('<<S>>', season_fill).replace('<<E>>', str_episode),
		string2.replace('<<S>>', str_season).replace('<<E>>', str_episode),
		string3.replace('<<S>>', season_fill).replace('<<E1>>', str_ep_minus_1.zfill(2)).replace('<<E2>>', episode_fill),
		string3.replace('<<S>>', season_fill).replace('<<E1>>', episode_fill).replace('<<E2>>', str_ep_plus_1.zfill(2)),
		string4.replace('<<S>>', season_fill).replace('<<E>>', episode_fill),
		string4.replace('<<S>>', str_season).replace('<<E>>', episode_fill),
		string5.replace('<<E>>', episode_fill),
		string5.replace('<<E>>', str_episode),
		string6.replace('<<E>>', episode_fill),
		string7.replace('<<E>>', episode_fill),
	]
	pattern = re.compile('|'.join(string_list))
	# Limit cache size to prevent unbounded growth
	if len(_seas_ep_pattern_cache) > 500:
		_seas_ep_pattern_cache.clear()
	_seas_ep_pattern_cache[key] = pattern
	return pattern

def seas_ep_filter(season, episode, release_title, split=False, return_match=False):
	release_title = _RE_NON_ALNUM_DASH.sub('.', unquote(release_title).replace('\'', '')).lower()
	reg_pattern = _get_seas_ep_pattern(season, episode)
	match = reg_pattern.search(release_title)
	if split:
		if not match: return release_title
		parts = release_title.split(match.group(), 1)
		return parts[1] if len(parts) > 1 else release_title
	elif return_match:
		return match.group() if match else ''
	else: return bool(match)

_EXTRAS_FILTER = ('sample', 'extra', 'extras', 'deleted', 'unused', 'footage', 'inside', 'blooper', 'bloopers', 'making.of', 'feature',
			'featurette', 'behind.the.scenes', 'trailer')

def extras_filter():
	return _EXTRAS_FILTER

def find_season_in_release_title(release_title):
	release_title = _RE_NON_ALNUM_DASH.sub('.', unquote(release_title).replace('\'', '')).lower()
	match = None
	for pattern in _RE_FIND_SEASON:
		try:
			match = pattern.search(release_title)
			if match:
				match = int(string(match.group(1)).lstrip('0'))
				break
		except Exception: pass
	return match

def check_title(title, release_title, aliases, year, season, episode):
	try:
		all_titles = [title]
		if aliases: all_titles += aliases
		cleaned_titles = []
		cleaned_titles_append = cleaned_titles.append
		year = string(year)
		for i in all_titles:
			cleaned_titles_append(
				i.lower().replace('\'', '').replace(':', '').replace('!', '').replace('(', '').replace(')', '').replace('&', 'and').replace(' ', '.').replace(year, ''))
		release_title = strip_non_ascii_and_unprintable(release_title).lstrip('/ ').replace(' ', '.').replace(':', '.').lower()
		releasetitle_startswith = release_title.startswith
		for tag in UNWANTED_TAGS:
			if releasetitle_startswith(tag):
				release_title = _UNWANTED_TAG_PATTERNS[tag].sub('', release_title, count=1)
		release_title = release_title.lstrip('.-:/')
		release_title = _RE_BRACKET_PREFIX.sub('', release_title, count=1)
		release_title = release_title.lstrip('.-[](){}:/')
		if season:
			if season == 'pack': hdlr = ''
			else:
				try: hdlr = seas_ep_filter(season, episode, release_title, return_match=True)
				except Exception: return False
		else: hdlr = year
		if hdlr:
			release_title = release_title.split(hdlr.lower())[0]
			release_title = release_title.replace(year, '').replace('(', '').replace(')', '').replace('&', 'and').replace(':', '').rstrip('.-')
			if not any(release_title == i for i in cleaned_titles): return False
		else:
			release_title = release_title.replace(year, '').replace('(', '').replace(')', '').replace('&', 'and').replace(':', '').rstrip('.-')
			if not any(i in release_title for i in cleaned_titles): return False
		return True
	except Exception: return True

_printable_set = frozenset(printable)

def strip_non_ascii_and_unprintable(text):
	try:
		result = ''.join(char for char in text if char in _printable_set)
		return result.encode('ascii', errors='ignore').decode('ascii', errors='ignore')
	except Exception: pass
	return text

def release_info_format(release_title):
	try:
		release_title = url_strip(release_title)
		release_title = release_title.lower().replace("'", "").lstrip('.').rstrip('.')
		fmt = '.%s.' % _RE_NON_ALNUM_DASH_TILDE.sub('.', release_title).replace('.-.', '.').replace('-.', '.').replace('.-', '.').replace('--', '.')
		return fmt
	except Exception:
		return release_title.lower()

def clean_title(title):
	try:
		if not title: return
		title = title.lower()
		title = _RE_HTML_ENTITY.sub('', title)
		title = _RE_HTML_ENTITY_FIX.sub('\\1;\\2', title)
		title = title.replace('&quot;', '\"').replace('&amp;', '&')
		title = _RE_CLEAN_TITLE.sub('', title)
	except Exception: pass
	return title

def get_release_quality(release_info):
	# Check pre-release qualities first (SCR/CAM/TELE take priority)
	for token in SCR:
		if token in release_info: return 'SCR'
	for token in CAM:
		if token in release_info: return 'CAM'
	for token in TELE:
		if token in release_info: return 'TELE'
	# Resolution detection - ordered by priority
	for token in RES_4K:
		if token in release_info: return '4K'
	for token in RES_1080:
		if token in release_info: return '1080p'
	for token in RES_720:
		if token in release_info: return '720p'
	return 'SD'

def url_strip(url):
	try:
		url = unquote_plus(url)
		if 'magnet:' in url and '&dn=' in url:
			parts = url.split('&dn=')
			url = parts[1] if len(parts) > 1 else url
		url = url.lower().replace("'", "").lstrip('.').rstrip('.')
		fmt = _RE_NON_ALNUM.sub(' ', url)
		if 'http' in fmt: return None
		if fmt == '': return None
		return fmt
	except Exception: return None

def _any_match(fmt, tokens):
	"""Check if any token exists in fmt. Uses direct iteration instead of any() generator."""
	for token in tokens:
		if token in fmt: return True
	return False

def get_file_info(name_info=None, url=None):
	# thanks 123Venom, whom I knicked most of this code from. :)
	info = []
	_append = info.append
	if name_info: fmt = name_info
	elif url: fmt = url_strip(url)
	else: fmt = None
	if not fmt: return ''
	quality = get_release_quality(fmt)
	# Video type detection
	if _any_match(fmt, VIDEO_3D): _append('[B]3D[/B]')
	# HDR/DV detection
	has_dv = has_hdr = False
	if '.sdr' in fmt: _append('SDR')
	elif _any_match(fmt, DOLBY_VISION):
		_append('[B]D/VISION[/B]')
		has_dv = True
	elif _any_match(fmt, HDR):
		_append('[B]HDR[/B]')
		has_hdr = True
	elif '2160p' in fmt and 'remux' in fmt:
		_append('[B]HDR[/B]')
		has_hdr = True
	if has_dv:
		if _any_match(fmt, HDR_TRUE):
			_append('[B]HDR[/B]')
			_append('[B]HYBRID[/B]')
			has_hdr = True
	# Codec detection
	if _any_match(fmt, CODEC_H264): _append('AVC')
	elif '.av1.' in fmt: _append('[B]AV1[/B]')
	elif _any_match(fmt, CODEC_H265): _append('[B]HEVC[/B]')
	elif has_hdr or has_dv: _append('[B]HEVC[/B]')
	elif _any_match(fmt, CODEC_XVID): _append('XVID')
	elif _any_match(fmt, CODEC_DIVX): _append('DIVX')
	# Source detection
	if _any_match(fmt, REMUX): _append('REMUX')
	if _any_match(fmt, BLURAY): _append('BLURAY')
	elif _any_match(fmt, DVD): _append('DVD')
	elif _any_match(fmt, WEB): _append('WEB')
	elif 'hdtv' in fmt: _append('HDTV')
	elif 'pdtv' in fmt: _append('PDTV')
	elif _any_match(fmt, HDRIP): _append('HDRIP')
	# Audio detection
	if 'atmos' in fmt: _append('ATMOS')
	if _any_match(fmt, DOLBY_TRUEHD): _append('TRUEHD')
	if _any_match(fmt, DOLBY_DIGITALPLUS): _append('DD+')
	elif _any_match(fmt, DOLBY_DIGITALEX): _append('DD-EX')
	elif _any_match(fmt, DOLBYDIGITAL): _append('DD')
	if 'aac' in fmt: _append('AAC')
	elif 'mp3' in fmt: _append('MP3')
	if _any_match(fmt, DTSX): _append('DTS-X')
	elif _any_match(fmt, DTS_HDMA): _append('DTS-HD MA')
	elif _any_match(fmt, DTS_HD): _append('DTS-HD')
	elif '.dts' in fmt: _append('DTS')
	# Channel detection
	if _any_match(fmt, AUDIO_8CH): _append('8CH')
	elif _any_match(fmt, AUDIO_7CH): _append('7CH')
	elif _any_match(fmt, AUDIO_6CH): _append('6CH')
	elif _any_match(fmt, AUDIO_2CH): _append('2CH')
	# Container detection
	if '.wmv' in fmt: _append('WMV')
	elif _any_match(fmt, CODEC_MPEG): _append('MPEG')
	elif '.avi' in fmt: _append('AVI')
	elif _any_match(fmt, CODEC_MKV): _append('MKV')
	# Misc flags
	if _any_match(fmt, MULTI_LANG): _append('MULTI-LANG')
	if _any_match(fmt, ADS): _append('ADS')
	if _any_match(fmt, SUBS): _append('SUBS')
	info = ' | '.join(info)
	return quality, info

def get_cache_expiry(media_type, meta, season):
	try:
		current_date = get_datetime()
		if media_type == 'movie':
			premiered = jsondate_to_datetime(meta['premiered'], '%Y-%m-%d', remove_time=True)
			difference = subtract_dates(current_date, premiered)
			if difference == 0: single_expiry = int(24*0.125)
			elif difference <= 90: single_expiry = int(24*0.334)
			else: single_expiry = 24*3
			season_expiry, show_expiry = 0, 0
		else:
			extra_info = meta['extra_info']
			ended = extra_info['status'] in ('Ended', 'Canceled')
			premiered = adjust_premiered_date(meta['premiered'], date_offset())[0]
			difference = subtract_dates(current_date, premiered)
			last_episode_to_air = jsondate_to_datetime(extra_info['last_episode_to_air']['air_date'], '%Y-%m-%d', remove_time=True)
			last_ep_difference = subtract_dates(current_date, last_episode_to_air)
			recently_ended = True if ended and last_ep_difference <= 14 else False
			if not ended or recently_ended:
				if difference == 0: single_expiry = int(24*0.125)
				elif difference <= 3: single_expiry = 24*1
				elif difference <= 7: single_expiry = 24*3
				else: single_expiry = 24*7
				if meta['total_seasons'] == season:
					if last_ep_difference <= 7: season_expiry = 24*3
					else: season_expiry = 24*10
				else: season_expiry = 24*30
				show_expiry = 24*10
			else: single_expiry, season_expiry, show_expiry = 24*10, 24*30, 24*30
	except Exception: single_expiry, season_expiry, show_expiry = 24*3, 24*3, 24*10
	return single_expiry, season_expiry, show_expiry

