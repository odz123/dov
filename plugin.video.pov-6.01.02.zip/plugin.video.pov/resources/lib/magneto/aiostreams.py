# created by kodifitzwell for Fenomscrapers
# Updated to support custom AIOStreams instances and user configuration
"""
	Fenomscrapers Project

	AIOStreams is a Stremio super-addon that consolidates multiple streaming
	addons (Comet, MediaFusion, Torrentio, etc.) and debrid services into
	a single, customizable interface.

	API Documentation: https://github.com/Viren070/AIOStreams/wiki/API-Documentation

	Users can:
	1. Use pre-configured public instances
	2. Provide a custom AIOStreams URL (self-hosted or ElfHosted)
	3. Provide their own user data configuration from the AIOStreams configure page
"""

import requests
from fenom import source_utils
from fenom.control import setting as getSetting

# Pre-configured public instances
# Note: Public instances may have rate limits or require configuration
PUBLIC_INSTANCES = (
	"https://aiostreams.kuu-lection.com",      # Kuu-lection instance
	"https://aiostreamsfortheweebs.midnightignite.me",  # Midnightignite instance
	"https://aiostreams.elfhosted.com"         # ElfHosted instance (requires subscription)
)

# Browser-like headers for HTTP requests
BROWSER_HEADERS = {
	'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
	'Accept': 'application/json, text/plain, */*',
	'Accept-Language': 'en-US,en;q=0.9',
}

# Default user data configuration (Comet + MediaFusion enabled)
DEFAULT_USER_DATA = (
	'ew0KICAicHJlc2V0cyI6IFsNCiAgICB7DQogICAgICAidHlwZSI6ICJ0b3JyZW50aW8iLA0KICAgICAg'
	'Imluc3RhbmNlSWQiOiAiZTdiIiwNCiAgICAgICJlbmFibGVkIjogZmFsc2UsDQogICAgICAib3B0aW9u'
	'cyI6IHsNCiAgICAgICAgIm5hbWUiOiAiVG9ycmVudGlvIiwNCiAgICAgICAgInRpbWVvdXQiOiAxMDAw'
	'MCwNCiAgICAgICAgInJlc291cmNlcyI6IFsic3RyZWFtIl0sDQogICAgICAgICJwcm92aWRlcnMiOiBb'
	'XSwNCiAgICAgICAgInVzZU11bHRpcGxlSW5zdGFuY2VzIjogZmFsc2UNCiAgICAgIH0NCiAgICB9LA0K'
	'ICAgIHsNCiAgICAgICJ0eXBlIjogImNvbWV0IiwNCiAgICAgICJpbnN0YW5jZUlkIjogImY3YiIsDQog'
	'ICAgICAiZW5hYmxlZCI6IHRydWUsDQogICAgICAib3B0aW9ucyI6IHsNCiAgICAgICAgIm5hbWUiOiAi'
	'Q29tZXQiLA0KICAgICAgICAidGltZW91dCI6IDEwMDAwLA0KICAgICAgICAicmVzb3VyY2VzIjogWyJz'
	'dHJlYW0iXSwNCiAgICAgICAgImluY2x1ZGVQMlAiOiB0cnVlLA0KICAgICAgICAicmVtb3ZlVHJhc2gi'
	'OiBmYWxzZQ0KICAgICAgfQ0KICAgIH0sDQogICAgew0KICAgICAgInR5cGUiOiAibWVkaWFmdXNpb24i'
	'LA0KICAgICAgImluc3RhbmNlSWQiOiAiNDUwIiwNCiAgICAgICJlbmFibGVkIjogdHJ1ZSwNCiAgICAg'
	'ICJvcHRpb25zIjogew0KICAgICAgICAibmFtZSI6ICJNZWRpYUZ1c2lvbiIsDQogICAgICAgICJ0aW1l'
	'b3V0IjogMTAwMDAsDQogICAgICAgICJyZXNvdXJjZXMiOiBbInN0cmVhbSJdLA0KICAgICAgICAidXNl'
	'Q2FjaGVkUmVzdWx0c09ubHkiOiB0cnVlLA0KICAgICAgICAiZW5hYmxlV2F0Y2hsaXN0Q2F0YWxvZ3Mi'
	'OiBmYWxzZSwNCiAgICAgICAgImRvd25sb2FkVmlhQnJvd3NlciI6IGZhbHNlLA0KICAgICAgICAiY29u'
	'dHJpYnV0b3JTdHJlYW1zIjogZmFsc2UsDQogICAgICAgICJjZXJ0aWZpY2F0aW9uTGV2ZWxzRmlsdGVy'
	'IjogW10sDQogICAgICAgICJudWRpdHlGaWx0ZXIiOiBbXQ0KICAgICAgfQ0KICAgIH0NCiAgXSwNCiAg'
	'ImZvcm1hdHRlciI6IHsNCiAgICAiaWQiOiAidG9ycmVudGlvIiwNCiAgICAiZGVmaW5pdGlvbiI6IHsi'
	'bmFtZSI6ICIiLCAiZGVzY3JpcHRpb24iOiAiIn0NCiAgfSwNCiAgInNvcnRDcml0ZXJpYSI6IHsiZ2xv'
	'YmFsIjogW119LA0KICAiZGVkdXBsaWNhdG9yIjogew0KICAgICJlbmFibGVkIjogZmFsc2UsDQogICAg'
	'ImtleXMiOiBbImZpbGVuYW1lIiwgImluZm9IYXNoIl0sDQogICAgIm11bHRpR3JvdXBCZWhhdmlvdXIi'
	'OiAiYWdncmVzc2l2ZSIsDQogICAgImNhY2hlZCI6ICJzaW5nbGVfcmVzdWx0IiwNCiAgICAidW5jYWNo'
	'ZWQiOiAicGVyX3NlcnZpY2UiLA0KICAgICJwMnAiOiAic2luZ2xlX3Jlc3VsdCIsDQogICAgImV4Y2x1'
	'ZGVBZGRvbnMiOiBbXQ0KICB9DQp9'
)


class source:
	timeout = 10
	priority = 1
	pack_capable = False # packs parsed in sources function
	hasMovies = True
	hasEpisodes = True
	def __init__(self):
		self.language = ['en']
		self.base_link = self._get_base_url()
		self.movieSearch_link = '/api/v1/search'
		self.tvSearch_link = '/api/v1/search'
		self.min_seeders = 0

	def _get_base_url(self):
		"""
		Get the AIOStreams instance URL based on user settings.
		Supports:
		- Pre-configured public instances (index 0-2)
		- Custom user-provided URL (index 3)
		"""
		instance_index = int(getSetting('aiostreams.url', '0'))
		if instance_index < len(PUBLIC_INSTANCES):
			return PUBLIC_INSTANCES[instance_index]
		# Custom URL
		custom_url = getSetting('aiostreams.custom_url', '').strip()
		if custom_url:
			# Remove trailing slash if present
			return custom_url.rstrip('/')
		# Fallback to first public instance
		return PUBLIC_INSTANCES[0]

	def _get_user_data(self):
		"""
		Get the user data configuration.
		If user has provided custom configuration, use that.
		Otherwise, use the default configuration.
		"""
		custom_data = getSetting('aiostreams.user_data', '').strip()
		if custom_data:
			return custom_data
		return DEFAULT_USER_DATA

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		sources_append = sources.append
		try:
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
			aliases = data['aliases']
			episode_title = data['title'] if 'tvshowtitle' in data else None
			total_seasons = data['total_seasons'] if 'tvshowtitle' in data else None
			year = data['year']
			imdb = data['imdb']
			if 'tvshowtitle' in data:
				season = data['season']
				episode = data['episode']
				hdlr = 'S%02dE%02d' % (int(season), int(episode))
				url = '%s%s' % (self.base_link, self.tvSearch_link)
				params = {'type': 'series', 'id': '%s:%s:%s' % (imdb, season, episode)}
			else:
				hdlr = year
				url = '%s%s' % (self.base_link, self.movieSearch_link)
				params = {'type': 'movie', 'id': '%s' % imdb}
			# log_utils.log('url = %s' % url)
			if 'timeout' in data: self.timeout = int(data['timeout'])

			base_headers = self._headers()

			results = requests.get(url, params=params, timeout=self.timeout, headers=base_headers)

			if results.status_code != 200:
				source_utils.scraper_error('AIOSTREAMS: HTTP %s from %s' % (results.status_code, self.base_link))
				return sources

			response = results.json()
			# Handle API response format: {"success": bool, "data": {"results": [...], "errors": [...]}}
			if not response.get('success', True):
				error = response.get('error', {})
				source_utils.scraper_error('AIOSTREAMS: %s' % error.get('message', 'Unknown error'))
				return sources
			files = response.get('data', {}).get('results', [])
			if not files:
				return sources
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except requests.exceptions.Timeout:
			source_utils.scraper_error('AIOSTREAMS: Timeout connecting to %s' % self.base_link)
			return sources
		except requests.exceptions.ConnectionError:
			source_utils.scraper_error('AIOSTREAMS: Connection error to %s' % self.base_link)
			return sources
		except Exception as e:
			source_utils.scraper_error('AIOSTREAMS: %s' % str(e))
			return sources

		for file in files:
			try:
				package, episode_start = None, 0
				hash = file.get('infoHash')
				direct_url = file.get('url')

				# Skip results without either infoHash or url
				if not hash and not direct_url:
					continue

				# Check if this is a debrid-resolved direct link
				is_debrid_direct = False
				if direct_url and not hash:
					is_debrid_direct = True

				# Get filename from various possible fields
				file_title = file.get('folderName') or file.get('filename') or file.get('name', '')
				file_title = file_title.replace('┈➤', '\n').split('\n')

				name = source_utils.clean_name(file_title[0])

				# Title validation - AIOStreams filters by IMDB ID so content is correct
				# We use lenient validation since many results have simplified names
				# For debrid-resolved direct links, be extra lenient as they often have minimal names
				if is_debrid_direct and not name:
					# Use a placeholder name for direct links without names
					name = 'Direct.Link'

				title_check = source_utils.check_title(title, aliases, name, hdlr, year)
				if not title_check and not is_debrid_direct:
					if total_seasons is not None:
						# TV show - try pack detection first
						valid, last_season = source_utils.filter_show_pack(title, aliases, imdb, year, season, name, total_seasons)
						if valid:
							package = 'show'
						else:
							valid, episode_start, episode_end = source_utils.filter_season_pack(title, aliases, year, season, name)
							if valid:
								package = 'season'
							else:
								# Lenient fallback - allow short names or names with quality info
								name_len = len(name.replace('.', '').replace('-', '').replace(' ', ''))
								has_quality_info = any(q in name.lower() for q in ('1080', '720', '2160', '4k', 'hdr', 'web', 'bluray'))
								if name_len > 30 and not has_quality_info:
									continue
					else:
						# Movie - lenient validation
						name_len = len(name.replace('.', '').replace('-', '').replace(' ', ''))
						has_quality_info = any(q in name.lower() for q in ('1080', '720', '2160', '4k', 'hdr', 'web', 'bluray'))
						if name_len > 30 and not has_quality_info:
							# Check if year is somewhere in the name
							if year not in name and str(int(year)-1) not in name and str(int(year)+1) not in name:
								continue
				name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				# Build URL based on stream type
				if hash:
					url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
				else:
					url = direct_url

				try:
					seeders = file.get('seeders', 0)
					if seeders is None: seeders = 0
					# Only apply seeder filter to torrents, not direct links
					if hash and self.min_seeders > seeders: continue
				except Exception: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				try:
					size = file.get('size', 0)
					if size:
						size_str = f"{float(size) / 1073741824:.2f} GB"
						dsize, isize = source_utils._size(size_str)
						info.insert(0, isize)
					else:
						dsize = 0
				except Exception: dsize = 0
				info = ' | '.join(info)

				# Build item based on stream type
				if is_debrid_direct:
					item = {
						'source': 'direct', 'language': 'en', 'direct': True, 'debridonly': False,
						'provider': 'aiostreams', 'url': url, 'name': name, 'name_info': name_info,
						'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders
					}
				else:
					item = {
						'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True,
						'provider': 'aiostreams', 'hash': hash, 'url': url, 'name': name, 'name_info': name_info,
						'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders
					}
				if package: item['package'] = package
				if package == 'show': item.update({'last_season': last_season})
				if episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end}) # for partial season packs
				sources_append(item)
			except Exception:
				source_utils.scraper_error('AIOSTREAMS')
		return sources

	def _headers(self):
		headers = BROWSER_HEADERS.copy()
		headers['x-aiostreams-user-data'] = self._get_user_data()
		return headers

