"""
	Fenomscrapers Module
"""

from datetime import datetime
import inspect
from fenom.control import transPath, setting as getSetting, lang, joinPath, existsPath

LOGDEBUG = 0
LOGINFO = 1
LOGWARNING = 2
LOGERROR = 3
LOGFATAL = 4
LOGNONE = 5 # not used

debug_list = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'FATAL']
DEBUGPREFIX = '[COLOR red][ FENOMSCRAPERS %s ][/COLOR]'
LOGPATH = transPath('special://logpath/')


def log(msg, caller=None, level=LOGINFO):
	debug_enabled = getSetting('debug.enabled') == 'true'
	if not debug_enabled: return
	debug_location = getSetting('debug.location')

	if isinstance(msg, int): msg = lang(msg) # for strings.po translations
	try:
		if not msg.isprintable(): # ex. "\n" is not a printable character so returns False on those sort of cases
			msg = '%s (NORMALIZED by log_utils.log())' % normalize(msg)
		if isinstance(msg, bytes):
			msg = '%s (ENCODED by log_utils.log())' % msg.decode('utf-8', errors='replace')

		if caller == 'scraper_error': pass
		elif caller is not None and level != LOGERROR:
			func = inspect.currentframe().f_back.f_code
			line_number = inspect.currentframe().f_back.f_lineno
			caller = "%s.%s()" % (caller, func.co_name)
			msg = '\nFrom func name: %s Line # :%s\n           msg: %s' % (caller, line_number, msg)
		elif caller is not None and level == LOGERROR:
			msg = '\nFrom func name: %s.%s() Line # :%s\n           msg: %s' % (caller[0], caller[1], caller[2], msg)

		if debug_location == '1':
			log_file = joinPath(LOGPATH, 'fenomscrapers.log')
			if not existsPath(log_file):
				with open(log_file, 'w') as f:
					pass
			reverse_log = getSetting('debug.reversed') == 'true'
			if not reverse_log:
				with open(log_file, 'a', encoding='utf-8') as f: # "with" auto cleans up and closes
					line = '[%s %s] %s: %s' % (datetime.now().date(), str(datetime.now().time())[:8], DEBUGPREFIX % debug_list[level], msg)
					f.write(line.rstrip('\r\n') + '\n')
					# f.writelines([line1, line2]) ## maybe an option for the 2 lines without using "\n"
			else:
				with open(log_file, 'r+', encoding='utf-8') as f:
					line = '[%s %s] %s: %s' % (datetime.now().date(), str(datetime.now().time())[:8], DEBUGPREFIX % debug_list[level], msg)
					log_file = f.read()
					f.seek(0, 0)
					f.write(line.rstrip('\r\n') + '\n' + log_file)
		else:
			import xbmc
			xbmc.log('%s: %s' % (DEBUGPREFIX % debug_list[level], msg), level)
	except Exception as e:
		import traceback
		traceback.print_exc()
		import xbmc
		xbmc.log('[ script.module.fenomonscrapers ] log_utils.log() Logging Failure: %s' % (e), LOGERROR)

def error(message=None, exception=True):
	try:
		import sys
		if exception:
			type, value, traceback = sys.exc_info()
#			addon = 'script.module.fenomscrapers'
			addon = 'plugin.video.pov'
			filename = (traceback.tb_frame.f_code.co_filename)
			parts = filename.split(addon)
			filename = parts[1] if len(parts) > 1 else filename
			name = traceback.tb_frame.f_code.co_name
			linenumber = traceback.tb_lineno
			errortype = type.__name__
			errormessage = value
			if str(errormessage) == '': return
			if message: message += ' -> '
			else: message = ''
			message += str(errortype) + ' -> ' + str(errormessage)
			caller = [filename, name, linenumber]
			del(type, value, traceback) # So we don't leave our local labels/objects dangling
		else:
			caller = None
		log(msg=message, caller=caller, level=LOGERROR)
	except Exception as e:
		import xbmc
		xbmc.log('[ script.module.fenomonscrapers ] log_utils.error() Logging Failure: %s' % (e), LOGERROR)

def clear_logFile():
	cleared = False
	try:
		from fenom.control import yesnoDialog
		if not yesnoDialog(lang(32060), '', ''): return 'canceled'
		log_file = joinPath(LOGPATH, 'fenomscrapers.log')
		if not existsPath(log_file):
			with open(log_file, 'w') as f:
				pass
			return None
		with open(log_file, 'r+') as f:
			f.truncate(0)  # need '0' when using r
		cleared = True
	except Exception as e:
		import xbmc
		xbmc.log('[ script.module.fenomonscrapers ] log_utils.clear_logFile() Failure: %s' % (e), LOGERROR)
		cleared = False
	return cleared

def view_LogFile(name):
	try:
		from fenom.textviewer import TextViewerXML
		from fenom.control import addonPath
		log_file = joinPath(LOGPATH, '%s.log' % name.lower())
		if not existsPath(log_file):
			from fenom.control import notification
			return notification(message='Log File not found, likely logging is not enabled.')
		with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
			text = f.read()
		heading = '[B]%s -  LogFile[/B]' % name
		windows = TextViewerXML('textviewer.xml', addonPath(), heading=heading, text=text)
		windows.run()
		del windows
	except Exception:
		error()

def upload_LogFile():
	from fenom.control import notification
	url = 'https://paste.kodi.tv/'
	log_file = joinPath(LOGPATH, 'fenomscrapers.log')
	if not existsPath(log_file):
		return notification(message='Log File not found, likely logging is not enabled.')
	try:
		import requests
		from fenom.control import addonVersion, selectDialog
		with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
			text = f.read()
		UserAgent = 'FenomScrpaers %s' % addonVersion()
		response = requests.post(url + 'documents', data=text.encode('utf-8', errors='ignore'), headers={'User-Agent': UserAgent}, timeout=30)
		# log('log_response: ' + str(response))
		response_data = response.json()
		if 'key' in response_data:
			result = url + response_data['key']
			log('FenomScrapers log file uploaded to: %s' % result)
			from sys import platform as sys_platform
			supported_platform = any(value in sys_platform for value in ('win32', 'linux2'))
			highlight_color = 'gold'
			url_list = [('[COLOR %s]url:[/COLOR]  %s' % (highlight_color, str(result)), str(result))]
			if supported_platform: url_list += [('[COLOR %s]  -- Copy url To Clipboard[/COLOR]' % highlight_color, ' ')]
			select = selectDialog([i[0] for i in url_list], lang(32059))
			if select is not None and 'Copy url To Clipboard' in url_list[select][0]:
				from fenom.source_utils import copy2clip
				copy2clip(url_list[select - 1][1])
		elif 'message' in response_data:
			notification(message='FenomScrapers Log upload failed: %s' % str(response_data['message']))
			log('FenomScrapers Log upload failed: %s' % str(response_data['message']), level=LOGERROR)
		else:
			notification(message='FenomScrapers Log upload failed')
			log('FenomScrapers Log upload failed: %s' % response.text, level=LOGERROR)
	except Exception:
		error('FenomScrapers log upload failed')
		notification(message='pastebin post failed: See log for more info')

def normalize(msg):
	try:
		import unicodedata
		msg = ''.join(c for c in unicodedata.normalize('NFKD', msg) if unicodedata.category(c) != 'Mn')
		return str(msg)
	except Exception:
		error()
		return msg

